import socket
import sys

def arithemetic_operation(first, operand, second):
    try:
        first = float(first)
        second = float(second)
        if operand == "+":
            return first + second
        elif operand == "-":
            return first - second
        elif operand == "*":
            return first * second
        elif operand == "/" and second == 0:
            return "................ERR: Divide by 0"
        elif operand == "/" and second != 0:
            return first / second
        else:
            return "................ERR: Invalid Operator"
    except:
        return "................ERR: Invalid Operand"

def perform_operation(data):
    maths_result = arithemetic_operation(data[0:16], data[32], data[16:32])
    if not isinstance(maths_result, basestring):
        if maths_result < 0:
            maths_result = str(maths_result)
            remaining_index = len(str(maths_result))
        else:
            maths_result = "+" + str(maths_result)
            remaining_index = len(str(maths_result))
        while (remaining_index < 16):
            maths_result += "0"
            remaining_index += 1
        return maths_result
    else:
        return maths_result

def tcp_server():
    while True:
        tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if (len(sys.argv) > 3):
            ip_address = socket.gethostbyname(sys.argv[2])
            port_number = int(sys.argv[3])
        else:
            ip_address = "127.0.0.1"
            port_number = int(sys.argv[2])
        tcp_socket.bind((ip_address, port_number))
        tcp_socket.listen(1)
        tcp_socket, addr = tcp_socket.accept()
        print 'Connection address:', addr
        while True:
            data = tcp_socket.recv(33)
            if not data:
                break
            print "Received Message:", data
            data = data.decode()
            modifiedMessage = perform_operation(data) + " from Luming"
            print "Modified Message =", modifiedMessage
            tcp_socket.send(modifiedMessage.encode("ASCII"))
        tcp_socket.close()

def udp_server():
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    if (len(sys.argv) > 3):
        ip_address = socket.gethostbyname(sys.argv[2])
        port_number = int(sys.argv[3])
    else:
        ip_address = "127.0.0.1"
        port_number = int(sys.argv[2])
    udp_socket.bind((ip_address, port_number))
    while True:
        data, addr = udp_socket.recvfrom(33)
        print "Received Message:", data
        data = data.decode()
        modifiedMessage = perform_operation(data) + " from Luming"
        print "Modified Message =", modifiedMessage
        udp_socket.sendto(modifiedMessage.encode("ASCII"), addr)

if (sys.argv[1] == "TCP"):
    tcp_server()
elif (sys.argv[1] == "UDP"):
    udp_server()
else:
    print "Invalid connection type specified."
