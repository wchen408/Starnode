import socket
import sys

def encode_calculation(user_input):
    (a, op, b) = user_input.split()
    return encode_input_num_argument(a) + encode_input_num_argument(b) + op

def encode_input_num_argument(number_argument):
    (current_start_pointer, current_end_pointer) = 0, 16
    has_decimal = False
    encoded_number_string = ""
    if number_argument[0] != "-":
        encoded_number_string += "+"
        current_end_pointer -= 1
    while current_start_pointer < len(number_argument):
        if (number_argument[current_start_pointer] == "."):
            has_decimal = True
        encoded_number_string += number_argument[current_start_pointer]
        current_start_pointer += 1
    if (has_decimal == False):
        encoded_number_string += "."
        current_start_pointer += 1
    for i in range (current_start_pointer, current_end_pointer):
        encoded_number_string += "0"
    return encoded_number_string

def prettify_number_string(number_string):
    new_string = number_string.rstrip('0')
    if (len(new_string) >= 2 and new_string[len(new_string) - 1] == "." and new_string[len(new_string) - 2] != "."):
        new_string = new_string[0:len(new_string) - 1]
    return new_string

def decode_server_response(server_response_message):
    (server_numerical_result, server_message) = "", ""
    if (server_response_message[0] == "-"):
        server_numerical_result = "-"
    else:
        server_numerical_result = ""
    for i in range (1, 16):
        server_numerical_result += server_response_message[i]
    server_message = server_response_message[16:len(server_response_message)]
    return prettify_number_string(server_numerical_result) + "," + server_message

def tcp_client():
    tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    if (len(sys.argv) > 3):
        ip_address = socket.gethostbyname(sys.argv[2])
        port_number = int(sys.argv[3])
    else:
        ip_address = "127.0.0.1"
        port_number = int(sys.argv[2])
    tcp_socket.connect((ip_address, port_number))
    should_break_connection = True
    while should_break_connection:
        user_input = raw_input("Please type an operation: ")
        if (user_input == "quit" or user_input == "Quit"):
            print "Bye..."
            tcp_socket.close()
            should_break_connection = False
        else:
            user_query = encode_calculation(user_input)
            tcp_socket.send(user_query.encode('ASCII'))
            tcp_result_message = decode_server_response(tcp_socket.recv(48).decode())
            print "[TCP] Result =", tcp_result_message

def udp_client():
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    if (len(sys.argv) > 3):
        ip_address = socket.gethostbyname(sys.argv[2])
        port_number = int(sys.argv[3])
    else:
        ip_address = "127.0.0.1"
        port_number = int(sys.argv[2])
    should_break_connection = True
    while should_break_connection:
        user_input = raw_input("Please type an operation: ")
        if (user_input == "quit" or user_input == "Quit"):
            print("Bye...")
            udp_socket.close()
            should_break_connection = False
        else:
            user_query = encode_calculation(user_input)
            udp_socket.sendto(user_query.encode('ASCII'), (ip_address, port_number))
            message_from_server, address_of_server = udp_socket.recvfrom(48)
            udp_result_message = decode_server_response(message_from_server.decode())
            print "[UDP] Result =", udp_result_message

if (sys.argv[1] == "TCP"):
    tcp_client()
elif (sys.argv[1] == "UDP"):
    udp_client()
else:
    print("Invalid connection type specified.")
